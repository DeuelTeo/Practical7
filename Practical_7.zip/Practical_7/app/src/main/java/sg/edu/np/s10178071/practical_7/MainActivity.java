package sg.edu.np.s10178071.practical_7;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    TextView txt;
    DbHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = findViewById(R.id.textViewCreate);
        txt.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Intent intent = new Intent(MainActivity.this,CreateNewUserActivity.class);
                startActivity(intent);
                return false;
            }
        });

    }

    public void onLogin (View v)

    {
        EditText Usertext = findViewById(R.id.editTextUsername);
        EditText Passtext = findViewById(R.id.editTextPassword);

        String username = Usertext.getText().toString();
        String password = Passtext.getText().toString();

        /*SharedPreferences prefs = getSharedPreferences("MY_GLOBAL_PREFS", MODE_PRIVATE);
        String username1 = prefs.getString("USER_NAME", "");
        String password1 = prefs.getString("PASSWORD", "");

        if (username.equals(username1) && password.equals(password1)) {

            Toast tt = Toast.makeText(MainActivity.this, "Valid.", Toast.LENGTH_LONG);//notification, cannot customize layout
            tt.show();
        }
        else
        {
            Toast tt = Toast.makeText(MainActivity.this,"Invalid.", Toast.LENGTH_LONG);//notification, cannot customize layout
            tt.show();
        }*/
        db.findAccount(username,password);
        if (db.findAccount(username,password)!=null) {

            Toast tt = Toast.makeText(MainActivity.this, "Login Successful.", Toast.LENGTH_LONG);//notification, cannot customize layout
            tt.show();

        }
        else
        {
            Toast tt = Toast.makeText(MainActivity.this,"Login Failed.", Toast.LENGTH_LONG);//notification, cannot customize layout
            tt.show();
        }


    }

}
