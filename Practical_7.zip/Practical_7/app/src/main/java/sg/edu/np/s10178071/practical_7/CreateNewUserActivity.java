package sg.edu.np.s10178071.practical_7;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateNewUserActivity extends AppCompatActivity {

    Button b;
    DbHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_user);
        db = new DbHandler(this,null,null, 1);
        b = findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() { // VERY IMPORTANT
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(CreateNewUserActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
    public void onCreateNewUser (View v)
    {
        EditText Usertext = findViewById(R.id.editTextUsername2);
        EditText Passtext = findViewById(R.id.editTextPassword2);

        String username = Usertext.getText().toString();
        String password = Passtext.getText().toString();

        Pattern passpattern = Pattern.compile("^(?=.*[0-9])(?=.*[!@#$%^&*+=])(?=.*[a-zA-Z]).{1,}$");
        Pattern userpattern = Pattern.compile("^[a-zA-Z0-9]{6,12}$");

        Matcher passmatcher = passpattern.matcher(password);
        Matcher usermatcher = userpattern.matcher(username);

        if (passmatcher.matches() == true && usermatcher.matches() == true) {

            //save data of User Name
            SharedPreferences.Editor editor = getSharedPreferences("MY_GLOBAL_PREFS", MODE_PRIVATE).edit();
            editor.putString("USER_NAME", username);
            editor.putString("PASSWORD", password);
            editor.apply();

            Account a = new Account(username, password);
            db.addAccount(a);
            Toast tt = Toast.makeText(CreateNewUserActivity.this, "New User Created Successfully.", Toast.LENGTH_LONG);//notification, cannot customize layout
            tt.show();
        }
        else
        {
            Toast tt = Toast.makeText(CreateNewUserActivity.this,"Invalid User Creation. Please Try Again.", Toast.LENGTH_LONG);//notification, cannot customize layout
            tt.show();
        }



    }



}

